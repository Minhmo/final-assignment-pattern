PCA is used, see run_test.m!!!!

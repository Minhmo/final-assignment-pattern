%GETSIZE_OUT Get size_out field of mapping
%
%    SIZE_OUT = GETSIZE_OUT(W)

% $Id: getsize_out.m,v 1.2 2006/03/08 22:06:58 duin Exp $

function size_out = getsize_out(w)

		prtrace(mfilename,2);

size_out = w.size_out;
return

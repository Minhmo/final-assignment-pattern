%NEWLINE The platform dependent newline character
%
% c = newline

% $Id: newline.m,v 1.3 2010/03/18 12:25:21 duin Exp $

function c = newline
	
	c = sprintf('\n');
	
return

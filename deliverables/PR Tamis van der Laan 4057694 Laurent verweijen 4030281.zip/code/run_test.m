%%FEATURE EXTRACTION TO USE
filename    = 'my_rep';

% Train classifier
clean = prnist([0:9],[1:100]);
HOG = my_rep(clean);
PCA = pca(HOG,0.99);
w = vpc(HOG*PCA,1000);

% Test it
large_error_PCA = nist_eval(filename,PCA*w,100)

